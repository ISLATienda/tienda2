<?php 

include("conexion.php");
$usuarios = "SELECT * FROM playeras_h"

?>

<?php 

include("conexion.php");
$usuarios1 = "SELECT * FROM blusas"

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="stylemostrar.css">
    <title>Document</title>
</head>
<body>

<div class="container-add">
    <h2 class="container__title">Registro Playeras</h2>
    <form action="insertar.php" method="post" class="container__form">
    <label for="" class="container__label">Color:</label>
    <input name="color" type="text" class="container__input">
    <label for="" class="container__label">Modelo:</label>
    <input name="modelo" type="text" class="container__input">
    <label for="" class="container__label">Talla:</label>
    <input name="talla" type="text" class="container__input">
    <label for="" class="container__label">Precio:</label>
    <input name="precio" type="number" class="container__input">
    <input class="container__submit" type="submit" value="registrar">
    </form>
</div>




    <div class="container-table">
    <div class="table__title">Playeras</div>
    <div class="table__header">Color</div>
    <div class="table__header">Modelo</div>
    <div class="table__header">Talla</div>
    <div class="table__header">Precio</div>
    <?php $resultado = mysqli_query($conexion,$usuarios);
    while($row=mysqli_fetch_assoc($resultado)){ ?> 
    <div class="table__item"><?php echo $row["Color"];?></div>
    <div class="table__item"><?php echo $row["modelo"];?></div>
    <div class="table__item"><?php echo $row["talla"];?></div>
    <div class="table__item">$<?php echo $row["precio"];?>MXN</div>
    <?php  } mysqli_free_result($resultado);?> 
    </div>
    <!------------------------------------------------------------------------------------------>
    <div class="container-add">
    <h2 class="container__title">Registro Blusas</h2>
    <form action="insertar.php" method="post" class="container__form">
    <label for="" class="container__label">Color:</label>
    <input name="color1" type="text" class="container__input">
    <label for="" class="container__label">Modelo:</label>
    <input name="modelo1" type="text" class="container__input">
    <label for="" class="container__label">Talla:</label>
    <input name="talla1" type="text" class="container__input">
    <label for="" class="container__label">Precio:</label>
    <input name="precio1" type="number" class="container__input">
    <input class="container__submit" type="submit" value="registrar" href="index.php">
    </form>
</div>




    <div class="container-table">
    <div class="table__title">Blusas</div>
    <div class="table__header">Color</div>
    <div class="table__header">Modelo</div>
    <div class="table__header">Talla</div>
    <div class="table__header">Precio</div>
    <?php $resultado1 = mysqli_query($conexion,$usuarios1);
    while($row=mysqli_fetch_assoc($resultado1)){ ?> 
    <div class="table__item"><?php echo $row["Color1"];?></div>
    <div class="table__item"><?php echo $row["modelo1"];?></div>
    <div class="table__item"><?php echo $row["talla1"];?></div>
    <div class="table__item">$<?php echo $row["precio1"];?>MXN</div>
    <?php  } mysqli_free_result($resultado1);?> 
    </div>
    <!------------------------------------------------------------------------------------------>


</body>
</html>