<!--comentario-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-widht, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="css/font.css">
     <link rel="stylesheet" href="css/blog.css"><!--linkeador del css-->
</head>

    <header class="header">
    <nav class="nav">
    <a href="#" class="logo nav-link">Logo</a><!--iria el logo en esta parte solo que es texto-->
    <ul class="nav-menu"><!--estructura del menu superior-->
         
         <li class="nav-menu-item"><a href="inicio.php" class="nav-menu-link nav-link ">Inicio</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaRopa.php" class="nav-menu-link nav-link ">Ropa</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="index.php" class="nav-menu-link nav-link ">usuario</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaBlog.php" class="nav-menu-link nav-link nav-menu-link_active">blog</a></li><!--nombre de las direcciones basias-->
    </ul>
</nav>
</header>
<body>
<div class="social-bar">
    <a href="https://www.facebook.com/DevCode.la" class="icon icon-facebook" target="_blank"></a>
    <a href="https://twitter.com/DevCodela" class="icon icon-twitter" target="_blank"></a>
    <a href="https://www.instagram.com/devcodela/" class="icon icon-instagram" target="_blank"></a>
  </div>
<center><br><br><br><br><br><br><br><h1>¿Quienes Somos?</h1><br><br>
    <p id=text>Durante 6 años de kamu´s se ah dedicado a la venta de ropa para sus clientes, kamu´s busca dar a conocer su empresa, asi como de llegar a mas ciudadanos por medios digitales para asi poder llegar a mas gente y ofrecer su catalogo de ropa a ellos.
    <br><br>   Asi mismo nuestro crecimiento se ah debido a la actualisacion y opiniones de nuestros clientes para facilitar el acceso de nuestro catalogo hacia nuestros clientes de manera rapida y remota, asi mismo la expancion es para la facilidad de nuestros clientes. </p>
    <br><br><br><br><h2>Mision</h2><br><br>
    <p id=text1>"Vendemos ropa, gracias a nuestra calidad en la elaboracion de nuestra exprtacion de telas de E.U. ropa de exelente calidad que ayudan a estrechar lazon con lo mas importante, Ustedes"</p>
    <br><br><br><br><h2>Vision</h2><br><br>
    <p id=text2>"Exelente calidad que esta a la altura de Ustedes"</p><br><br><br><br>
    
 <img src="imge/tienda-ropa.jpg" height ="400" width="700">

   </center> 
 
</body>
</html>

