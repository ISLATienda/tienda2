<?php

  session_start();/*permite la utilisacion de session  */


  require 'database.php';/*solicita los datos de conexion dl archivo */

  if (!empty($_POST['email']) && !empty($_POST['password'])) {/*verifica si hay variables */ 
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE email = :email');/* selecciona los campos y los almacena */
    $records->bindParam(':email', $_POST['email']);/* reemplaza los campos que estan */ 
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $message = '';/*variable de mensaje vacio */

    if (count($results) > 0 && password_verify($_POST['password'], $results['password'])) {
      $_SESSION['user_id'] = $results['id'];/*verifica el campo por la variable sesion */
      header("Location: /inicio.php");
    } else {
      $message = 'los parametro escritos no coniciden';
    }
  }
  ?>
<!DOCTYPE html>
<html>
  <head>
    
    <title>Login</title>
    
    <link rel="stylesheet" href="css/stylelogin.css">
  </head>
  <body>
    

    <?php if(!empty($message)): ?><!--verifica si la variabler esta vacia-->
      <p> <?= $message ?></p><!--muestra el mensaje que tiene en caso de tenerlo-->
    <?php endif; ?><!--final del if-->

   
    
    <section class="form-login">
    <h5>Login</h5>
    <form action="login.php" method="POST">
      <input class="controls" name="email" type="text" placeholder="Enter your email">
      <input class="controls" name="password" type="password" placeholder="Enter your Password">
      <input class="buttons" type="submit" value="Iniciar">
      <a href="signup.php">¿No tienes cuenta? Registrate aqui</a><br></br>
      <a href="inicio.php">inicio</a>
      </section></form>
  </body>
</html>
