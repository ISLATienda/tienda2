<?php 

$conexion = mysqli_connect("localhost","root","","login");
mysqli_set_charset($conexion,"utf8");


?>