#include<iostream>
#include<conio.h>

using namespace std;

void ingresar_arreglo();
void orden(int [],int,int&);
void resultado(int&,int);

int arreglo[100],tam,M=0;

int main(){

 ingresar_arreglo();
 orden(arreglo,tam,M);
 resultado(M,tam);

 getch();
 return 0;
}

void ingresar_arreglo(){
 cout<<"Ingrese el numero de datos que tendra el arreglo: ";
 cin>>tam;

 for(int i=0;i<tam;i++){
  cout<<i+1<<". Ingrese el numero que ira en la posicion ["<<i<<"]: ";
  cin>>arreglo[i];
 }
}

void orden(int arreglo[],int tam,int& M){
 for(int i=1;i<tam;i++){
  if(arreglo[i-1]<arreglo[i]){
   M = M+1;
  }
 }
}

void resultado(int& M,int tam){
 char flg = 'F';

 if(M == tam-1){
  flg = 'V';
 }
 else {
  flg = 'F';
 }

 switch(flg){
  case 'V': cout<<"El arreglo esta ordenado de forma ascendente."<<endl; break;
  case 'F': cout<<"El arreglo no esta ordenado de forma ascendente."<<endl; break;
 }
}
