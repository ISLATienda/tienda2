#include<iostream>
using namespace std;
int main(){
int A[20],B[20],C[3],n,m;
cout<<"Cuantos valores quiere en el primer arreglo : ";
cin>>m;
for(int i=0;i<m;i++){
    cout<<"introduzca el valor ["<<i<<"]";
    cin>>A[i];
}
cout<<"Cuantos valores quiere en el segundo arreglo : ";
cin>>n;
for(int i=0;i<n;i++){
    cout<<"introduzca el valor ["<<i<<"]";
    cin>>B[i];
}
cout<<"La suma de los arreglos es: ";
for(int i=0;i<n;i++){
    C[i]= A[i] + B[i];
    cout<<"  "<<C[i]<<" ";

}
cout<<endl;
cout<<"La suma de los arreglos es: ";
for(int i=0;i<m;i++){
    C[i]= A[i] + B[i];
    cout<<"  "<<C[i]<<" ";

}





}
