<!--comentario-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-widht, initial-scale=1.0">
    <title>Navbar</title>
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/styleInicio.css"><!--linkeador del css-->
    
</head>
<body>
    <header class="header">
    <nav class="nav">
    <a href="#" class="logo nav-link">Kamu´s</a><!--iria el logo en esta parte solo que es texto-->
    <ul class="nav-menu"><!--estructura del menu superior-->
         
        <li class="nav-menu-item"><a href="inicio.php" class="nav-menu-link nav-link nav-menu-link_active">Inicio</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaRopa.php" class="nav-menu-link nav-link ">Ropa</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="index.php" class="nav-menu-link nav-link ">usuario</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaBlog.php" class="nav-menu-link nav-link ">Blog</a></li><!--nombre de las direcciones basias-->
    </ul>
</nav>
</header>
<center><h1>Bienvenido a kamu´s</h1></center>

<div class="container">
 <ul class="slider">
   <li id="slide1">
       <img src="imge/login.jpg">
   </li>
   <li id="slide2">
    <img src="imge/login1.jpg">
</li>
<li id="slide3">
 <img src="imge/login2.jpg">
</li>
 </ul>
 <ul class="menu">
     <li>
         <a href="#slide1">1</a>
     </li>
     <li>
        <a href="#slide2">2</a>
    </li>
    <li>
        <a href="#slide3">3</a>
    </li>
 </ul>
</div>
<div class="social-bar">
    <a href="https://www.facebook.com" class="icon icon-facebook" target="_blank"></a>
    <a href="https://twitter.com" class="icon icon-twitter" target="_blank"></a>
    <a href="https://www.instagram.com" class="icon icon-instagram" target="_blank"></a>
  </div>
<center><h1>Conoce mas de nosotros<a href="paginaBlog.php" class=" "><br>Aqui</a></h1><br><br>
<p id=text>Durante 6 años de kamu´s se ah dedicado a la venta de ropa para sus clientes, kamu´s busca dar a conocer su empresa, asi como de llegar a mas ciudadanos por medios digitales para asi poder llegar a mas gente y ofrecer su catalogo de ropa a ellos.
    <br><br>   Asi mismo nuestro crecimiento se ah debido a la actualisacion y opiniones de nuestros clientes para facilitar el acceso de nuestro catalogo hacia nuestros clientes de manera rapida y remota, asi mismo la expancion es para la facilidad de nuestros clientes.</p>
    </center>
</body>
</html>
