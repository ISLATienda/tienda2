<?php

  

  $message = '';

  if (!empty($_POST['email']) && !empty($_POST['password'])) {
    $sql = "INSERT INTO users (email, password) VALUES (:email, :password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email', $_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);

    if ($stmt->execute()) {
      $message = 'creado correctamente';
    } else {
      $message = 'hay un problema al crear la cuenta';
    }
  }
?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Registro</title>

    <link rel="stylesheet" href="css/styleregistro.css">
  </head>

  <body>



    <?php if(!empty($message)): ?>
      <a> <?= $message ?></a>
    <?php endif; ?>

    <section class = "form-registro">
    <h4>Registro</h4>

    <form action="signup.php" method="POST">
    <input class="control" type="text" name="email" placeholder="Ingrese su Correo">
      <input class="control" type="password" name="password"  placeholder="Ingrese su Contraseña">

      <input class="boton" type="submit" value="Registrar">
       <a href="login.php">inicia sesion</a>
      </section></form>

  </body>
</html>
