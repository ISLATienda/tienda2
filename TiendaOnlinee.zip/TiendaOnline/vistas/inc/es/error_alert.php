<div class="bg-danger text-white text-center mb-4" style="padding: 20px 0;">
    <p><i class="fas fa-exclamation-triangle fa-5x"></i></p>
    <h4>¡Ocurrió un error inesperado!</h4>
    <p class="mb-0">Lo sentimos, no podemos mostrar la información solicitada debido a un error.</p>        
</div>