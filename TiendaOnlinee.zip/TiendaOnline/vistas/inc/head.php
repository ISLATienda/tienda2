<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
<title><?php echo COMPANY; ?></title>

<!-- Normalize V8.0.1 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/normalize.css">

<!-- MDBootstrap V5 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/mdb.min.css">

<!-- Font Awesome V5.15.1 -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/all.css">

<!-- Sweet Alert V10.14.0 -->
<script src="<?php echo SERVERURL; ?>vistas/js/sweetalert2.js" ></script>

<!-- General Styles -->
<link rel="stylesheet" href="<?php echo SERVERURL; ?>vistas/css/style.css">