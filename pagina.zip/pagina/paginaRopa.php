<?php

include("conexion.php");
$usuarios = "SELECT * FROM playeras_h"

?>

<?php

include("conexion.php");
$usuarios1 = "SELECT * FROM blusa"

?>





<!--comentario-->
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-widht, initial-scale=1.0">
    <title>paginaRopa</title>
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/stylemostrar.css">
    <link rel="stylesheet" href="css/ropa.css"><!--linkeador del css-->
</head>
<body>
<div class="social-bar">
    <a href="https://www.facebook.com" class="icon icon-facebook" target="_blank"></a><!--tipo de target que tendra abrir en otra pagina-->
    <a href="https://twitter.com" class="icon icon-twitter" target="_blank"></a>
    <a href="https://www.instagram.com/devcodela/" class="icon icon-instagram" target="_blank"></a>
  </div>
    <header class="header">
    <nav class="nav">
    <a href="#" class="logo nav-link">ISLA</a><!--iria el logo en esta parte solo que es texto-->
    <ul class="nav-menu"><!--estructura del menu superior-->

         <li class="nav-menu-item"><a href="inicio.php" class="nav-menu-link nav-link ">Inicio</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaRopa.php" class="nav-menu-link nav-link nav-menu-link_active">Ropa</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="index.php" class="nav-menu-link nav-link ">usuario</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaBlog.php" class="nav-menu-link nav-link ">Blog</a></li><!--nombre de las direcciones basias-->
    </ul>
</nav>
</header><br><br><br>
<div class="container-table">
    <div class="table__title">Playeras</div>
    <div class="table__header">Color</div>
    <div class="table__header">Modelo</div>
    <div class="table__header">Talla</div>
    <div class="table__header">Precio</div>
    <?php $resultado = mysqli_query($conexion,$usuarios);
    while($row=mysqli_fetch_assoc($resultado)){ ?>
    <div class="table__item"><?php echo $row["Color"];?></div>
    <div class="table__item"><?php echo $row["modelo"];?></div>
    <div class="table__item"><?php echo $row["talla"];?></div>
    <div class="table__item">$<?php echo $row["precio"];?>MXN</div>
    <?php  } mysqli_free_result($resultado);?>
    </div>
    <!------------------------------------------------------------------------------------------>
    <div class="container-table">
    <div class="table__title">Blusas</div>
    <div class="table__header">Color</div>
    <div class="table__header">Modelo</div>
    <div class="table__header">Talla</div>
    <div class="table__header">Precio</div>
    <?php $resultado1 = mysqli_query($conexion,$usuarios1);
    while($row=mysqli_fetch_assoc($resultado1)){ ?>
    <div class="table__item"><?php echo $row["Color1"];?></div>
    <div class="table__item"><?php echo $row["modelo1"];?></div>
    <div class="table__item"><?php echo $row["talla1"];?></div>
    <div class="table__item">$<?php echo $row["precio1"];?>MXN</div>
    <?php  } mysqli_free_result($resultado1);?>
    </div>
    <!------------------------------------------------------------------------------------------>
</body>
</html>
