#include <iostream>

using namespace std;
int main(){

int val1 = 0;

int val2 = 0;

int val3 = 0;

int val4 =0;

int res = 0;

cout<<"ingresa la primer calificacion"<<endl;

cin>>val1;

cout<<"ingresa la segunda calificacion"<<endl;

cin>>val2;
cout<<"ingresa la tercera calificacion"<<endl;

cin>> val3;
cout<<"ingresa la cuarta calificacion"<<endl;

cin>> val4;

res = (val1 +val2 +val3 +val4)/4;

cout<<"El promedio es: "<< res<<endl;
if(res<=6){
    cout<<"reprobado";
}else{
    cout<<"aprobado"<<endl;
}
if(res>=9){
    cout<<"felicidades";
}
}

