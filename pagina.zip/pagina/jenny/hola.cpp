#include<iostream>
using namespace std;
int main(){
int arreglo[]{1,5,8,9,4};
int suma=0;

for(int i=0;i<=5;i++){
    cout<<"la suma del arreglo es: "<<suma<<endl;
    suma += arreglo[i] ;
}
return 0;
}
