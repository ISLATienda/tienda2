<?php

$conexion = mysqli_connect("152.67.231.40","root","","tienda");
mysqli_set_charset($conexion,"utf8");


?>
