<?php


$message = '';

if(!empty($_POST['email']) && !empty($_POST['password'])){
    $sql = "INSERT INTO users (email,password) VALUES (:email,:password)";
    $stmt = $conn->prepare($sql);
    $stmt->bindParam(':email',$_POST['email']);
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
    $stmt->bindParam(':password', $password);

    if ($stmt->execute()){
        $message = 'creado un nuevo usuario';
    }else{
        $message = 'ah ocurrido algo en la base de datos';
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Registro</title>
    <link rel="stylesheet" href="css/styleregistro.css">
</head>
<body>
<?php if(!empty($message)):?>
        <p><?php $message?></p>
        <?php endif; ?>
        <form action="registrologin.php" method= get name="agrupa".>
    <section class="form-registro">
        <h4>Registro</h4>
        <input class="control" type="text" name="Nombres" id="nombres" placeholder="Ingrese su Nombre">
        <input class="control" type="text" name="Apellidos" id="Apellidos" placeholder="Ingrese su Apelidos">
        <input class="control" type="email" name="email" id="Correo" placeholder="Ingrese su Correo">
        <input class="control" type="password" name="password" id="Correo" placeholder="Ingrese su Contraseña">
        <p>estoy de acuerdo con <a href="#">Terminos Y Condiciones</a></p>
        <input class="boton" type="submit" value="Registrar">
         <p><a href="menuloggin.php">¿Ya tienes cuenta? Pulsa aqui</a></p>
    </section></form>
</body>
</html>
