<?php

$server = '152.67.231.40';
$username = 'root';
$password = '';
$database = 'tienda';

try {
  $conn = new PDO("mysql:host=$server;dbname=$database;", $username, $password);
} catch (PDOException $e) {
  die('Connection Failed: ' . $e->getMessage());
}

?>
