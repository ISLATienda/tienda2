<?php 

include("conexion.php");

$color = $_POST["color"];
$modelo = $_POST["modelo"];
$talla = $_POST["talla"];
$precio = $_POST["precio"];

$insertar ="INSERT INTO playeras_h(Color,modelo,talla,precio1) VALUES('$color', '$modelo', '$talla', '$precio')";
$resultado = mysqli_query($conexion,$insertar);
if($resultado){
    echo"<script>alert('se ah registrado correctamente');window.location='/dbProductos'</script>";
}else {
    echo"<scrip>alert('no se registro');window.history.go(-1);</script>";
}

?>


<!---------------------------------------------------------------------------------------------------------------------->


<?php 

include("conexion.php");

$color1 = $_POST["color1"];
$modelo1 = $_POST["modelo1"];
$talla1 = $_POST["talla1"];
$precio1 = $_POST["precio1"];

$insertar1 ="INSERT INTO blusas(Color1,modelo1,talla1,precio1) VALUES('$color1', '$modelo1', '$talla1', '$precio1')";
$resultado1 = mysqli_query($conexion,$insertar1);
if($resultado1){
    echo"<script>alert('se ah registrado correctamente');window.location='/dbProductos'</script>";
}else {
    echo"<scrip>alert('no se registro');window.history.go(-1);</script>";
}

?>


<!---------------------------------------------------------------------------------------------------------------------->





