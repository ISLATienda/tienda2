<?php

$conexion = mysqli_connect("152.67.231.40","root","","Final");
mysqli_set_charset($conexion,"utf8");


?>
