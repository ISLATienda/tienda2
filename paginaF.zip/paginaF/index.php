<?php
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, email, password FROM users WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>

<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Welcome to you WebApp</title>
    <link rel="stylesheet" href="css/font.css">
    <link rel="stylesheet" href="css/styleInicio.css">
    <link rel="stylesheet" href="assets/css/style.css">
  </head>
  <body>
  <div class="social-bar">
    <a href="https://www.facebook.com" class="icon icon-facebook" target="_blank"></a><!--tipo de target que tendra abrir en otra pagina-->
    <a href="https://twitter.com" class="icon icon-twitter" target="_blank"></a>
    <a href="https://www.instagram.com/devcodela/" class="icon icon-instagram" target="_blank"></a>
  </div>
  <header class="header">
    <nav class="nav">
    <a href="#" class="logo nav-link">Kamu´s</a><!--iria el logo en esta parte solo que es texto-->
    <ul class="nav-menu"><!--estructura del menu superior-->

        <li class="nav-menu-item"><a href="inicio.php" class="nav-menu-link nav-link ">Inicio</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaRopa.php" class="nav-menu-link nav-link ">Ropa</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="index.php" class="nav-menu-link nav-link nav-menu-link_active">usuario</a></li><!--nombre de las direcciones basias-->
         <li class="nav-menu-item"><a href="paginaBlog.php" class="nav-menu-link nav-link ">Blog</a></li><!--nombre de las direcciones basias-->
    </ul>
</nav>
</header>
<center>
    <?php if(!empty($user)): ?>
      <br> <h1>Welcome. <?= $user['email']; ?>
      <br>You are Successfully Logged In</h1>
      <a href="logout.php">
        Logout
      </a>
    <?php else: ?> <br><br> <br><br>
      <h1>Registrate o Inicia sesion</h1>
      <br><br><h3>
      <a href="login.php">iniciar sesion</a>   or
      <a href="signup.php">registrarse</a></h3>

    <?php endif; ?></center>
  </body>
</html>
