<?php

$conexion=mysqli_connect("localhost","root","","loggin");


?>
<H1>CONECTADO</H1>